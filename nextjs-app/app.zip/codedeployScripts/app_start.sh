echo "app start ;)"

cd /nextjs-app
npm install
npm run build
npm run start &
