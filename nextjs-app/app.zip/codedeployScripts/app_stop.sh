echo "app stop ;)"

killall node
rm -rf /nextjs-app
